const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");

function fakeElement() {
  return {
    value: "",
    textContent: "",
    innerHTML: "",
    hidden: false,
    disabled: false,
    dataset: {},
    style: {},
    classList: {
      add() {},
      remove() {},
      toggle() {},
      contains() { return false; }
    },
    appendChild() {},
    remove() {},
    focus() {},
    select() {},
    scrollIntoView() {},
    addEventListener() {},
    querySelector() { return fakeElement(); },
    querySelectorAll() { return []; },
    closest() { return null; },
    matches() { return false; }
  };
}

const elements = new Map();
const context = {
  assert,
  console,
  Intl,
  JSON,
  Math,
  Date,
  Number,
  String,
  Boolean,
  Array,
  Object,
  Map,
  Set,
  Promise,
  clearTimeout() {},
  setTimeout() { return 0; },
  localStorage: {
    getItem() { return null; },
    setItem() {},
    removeItem() {}
  },
  document: {
    querySelector(selector) {
      if (!elements.has(selector)) elements.set(selector, fakeElement());
      return elements.get(selector);
    },
    querySelectorAll() { return []; },
    createElement() { return fakeElement(); },
    body: fakeElement(),
    documentElement: { dataset: {} }
  },
  navigator: {},
  location: { protocol: "http:" },
  window: {}
};

context.window = context;
vm.createContext(context);

const files = [
  "js/01-core.js",
  "js/02-domain.js",
  "js/04-customers-invoices.js",
  "js/08-checkout.js",
  "js/09-actions.js"
];

for (const file of files) {
  vm.runInContext(fs.readFileSync(path.join(root, file), "utf8"), context, { filename: file });
}

const scenario = `
render = function () {};
renderMenu = function () {};
renderOrderTotals = function () {};
renderStats = function () {};
renderTables = function () {};
renderCustomerDetail = function () {};
renderCustomers = function () {};
renderInvoices = function () {};
renderActiveView = function () {};
renderBackupReminder = function () {};
applyBusinessName = function () {};
applyAppTheme = function () {};

state = defaultState();
state.menu = normalizeMenuItems([
  {
    id: "coffee",
    name: "قهوة",
    price: 8,
    cost: 2,
    category: "مشروبات",
    options: [{ id: "large", label: "كبير", price: 12 }]
  },
  { id: "tea", name: "شاي", price: 6, cost: 1, category: "مشروبات" }
]);
state.customers = [];
state.invoices = [];
state.openOrders = {};
state.auditLog = [];

function resetCheckoutFields() {
  els.customerNameInput.value = "";
  els.customerPhoneInput.value = "";
  els.customerSelect.value = "";
  els.discountInput.value = "";
  els.paymentMethodInput.value = "cash";
  els.paymentAmountInput.value = "";
  els.changeReturnedInput.value = "";
  els.noteInput.value = "";
}

resetCheckoutFields();

addMenuItemFromGrid("coffee", "large");
let order = getOpenOrder();
assert.strictEqual(order.items.length, 1);
assert.strictEqual(order.items[0].name, "قهوة - كبير");
assert.strictEqual(order.items[0].price, 12);
addMenuItemFromGrid("coffee");
assert.strictEqual(order.items.length, 1);
assert.strictEqual(order.items[0].qty, 2);

els.paymentAmountInput.value = "24";
closeInvoice();
assert.strictEqual(state.invoices.length, 1);
assert.strictEqual(state.invoices[0].status, "paid");
assert.strictEqual(state.invoices[0].paid, 24);

resetCheckoutFields();
addItem("tea");
els.customerNameInput.value = "أبو أحمد";
closeInvoice();
assert.strictEqual(state.invoices.length, 2);
assert.strictEqual(state.invoices[0].status, "debt");
const customer = state.customers.find((item) => item.name === "أبو أحمد");
assert(customer);
assert.strictEqual(customer.balance, 6);

selectedCustomerId = customer.id;
els.settlementAmountInput.value = "5";
els.settlementDiscountInput.value = "";
els.settlementMethodInput.value = "cash";
settlementDebtMode = false;
recordSettlement({ preventDefault() {} });

assert.strictEqual(state.invoices.length, 3);
assert.strictEqual(state.invoices[0].type, "payment");
assert.strictEqual(customer.balance, 1);

rebuildCustomerAccountsFromInvoices(state);
assert.strictEqual(customer.balance, 1);

const customerId = customer.id;
assert.strictEqual(updateCustomerInfo(customerId, "أبو محمد", "0591234567"), true);
assert.strictEqual(customer.id, customerId);
assert.strictEqual(customer.name, "أبو محمد");
assert.strictEqual(customer.phone, "0591234567");
assert.strictEqual(customer.balance, 1);
assert(state.invoices.filter((invoice) => invoice.customerId === customerId).every((invoice) => invoice.customerName === "أبو محمد"));

const health = dataHealthReport(state);
assert.strictEqual(health.ok, true, health.issues.join(", "));
`;

vm.runInContext(scenario, context, { filename: "flow-scenario.js" });

console.log("Business flow scenario passed.");
