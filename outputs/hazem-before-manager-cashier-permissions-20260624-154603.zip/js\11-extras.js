// ═══ دفتر المقهى ═══ 11-extras.js — تذكير النسخ، تقرير اليوم، نقص المخزون، الأكثر مبيعاً
// (مقسوم من app.js — الأسطر 5342-5518)

// ─── End Period Close ───────────────────────────────────────────────────────

// ─── النسخ الاحتياطي: تذكير أسبوعي ──────────────────────────────────────────

const LAST_BACKUP_KEY = "cafe-pos-last-backup-at";
const BACKUP_SNOOZE_KEY = "cafe-pos-backup-snooze-until";

function markBackupDone() {
  localStorage.setItem(LAST_BACKUP_KEY, new Date().toISOString());
  els.backupReminderBanner.hidden = true;
}

function renderBackupReminder() {
  const hasData = state.invoices.length || (state.purchases || []).length;
  if (!hasData) { els.backupReminderBanner.hidden = true; return; }

  const snoozeUntil = localStorage.getItem(BACKUP_SNOOZE_KEY);
  if (snoozeUntil && new Date() < new Date(snoozeUntil)) {
    els.backupReminderBanner.hidden = true;
    return;
  }

  const last = localStorage.getItem(LAST_BACKUP_KEY);
  const days = last ? Math.floor((Date.now() - new Date(last).getTime()) / 86400000) : null;
  const due = !last || days >= 7;
  els.backupReminderBanner.hidden = !due;
  if (due) {
    const text = document.getElementById("backupReminderText");
    if (text) {
      text.textContent = last
        ? `⚠️ آخر نسخة احتياطية قبل ${days} يوم — صدّر نسخة واحفظها على جوجل درايف أو ابعثها واتساب لنفسك!`
        : "⚠️ ما في ولا نسخة احتياطية — بياناتك كلها على هذا الجهاز فقط! صدّر نسخة الآن.";
    }
  }
}

function snoozeBackupReminder() {
  const tomorrow = new Date(Date.now() + 86400000);
  localStorage.setItem(BACKUP_SNOOZE_KEY, tomorrow.toISOString());
  els.backupReminderBanner.hidden = true;
}

// ─── تنقّل الجوال: قائمة المزيد ───────────────────────────────────────────────

const MOBILE_MORE_VIEWS = ["settings", "purchases", "inventory", "expenses", "close", "guide"];

function openMoreSheet() {
  if (els.mobileMoreSheet) els.mobileMoreSheet.hidden = false;
}

function closeMoreSheet() {
  if (els.mobileMoreSheet) els.mobileMoreSheet.hidden = true;
}

function syncMobileMoreActive() {
  if (!els.mobileMoreButton) return;
  els.mobileMoreButton.classList.toggle("is-active", MOBILE_MORE_VIEWS.includes(state.view));
}

// ─── اسم المحل + صفحة الدليل ─────────────────────────────────────────────────

function businessName() {
  return (state.businessName && state.businessName.trim()) || "دفتر المقهى";
}

function applyBusinessName() {
  const name = businessName();
  if (els.brandTitle) els.brandTitle.textContent = name;
  if (els.brandMark) els.brandMark.textContent = name.trim().charAt(0) || "د";
  document.title = `${name} | نظام طاولات وفواتير`;
}

function appTheme() {
  return state.theme === "dark" ? "dark" : "light";
}

function applyAppTheme() {
  const theme = appTheme();
  document.documentElement.dataset.theme = theme;
  document.body.dataset.theme = theme;
  try {
    localStorage.setItem(APP_THEME_KEY, theme);
  } catch (error) {
    // تجاهل منع التخزين في بعض المتصفحات.
  }
  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) metaTheme.setAttribute("content", theme === "dark" ? "#09141a" : "#0f8b8d");
  if (els.themeToggleButton) {
    els.themeToggleButton.classList.toggle("is-dark", theme === "dark");
    els.themeToggleButton.setAttribute("aria-pressed", theme === "dark" ? "true" : "false");
    const icon = els.themeToggleButton.querySelector(".theme-toggle-icon");
    const text = els.themeToggleButton.querySelector(".theme-toggle-text");
    if (icon) icon.textContent = theme === "dark" ? "☀" : "☾";
    if (text) text.textContent = theme === "dark" ? "نهاري" : "ليلي";
  }
}

let themeSwitchTimer = null;
function toggleAppTheme() {
  state.theme = appTheme() === "dark" ? "light" : "dark";
  // تفعيل الانتقال الناعم لحظة التبديل فقط (حتى لا يبطّئ التحميل أو حركات الأزرار).
  const root = document.documentElement;
  root.classList.add("theme-switching");
  if (themeSwitchTimer) clearTimeout(themeSwitchTimer);
  themeSwitchTimer = setTimeout(() => root.classList.remove("theme-switching"), 450);
  applyAppTheme();
  saveState();
  showToast(state.theme === "dark" ? "تم تشغيل الوضع الليلي." : "تم تشغيل الوضع النهاري.");
}

function saveBusinessName() {
  const value = (els.businessNameInput.value || "").trim();
  if (!value) { showToast("اكتب اسم المحل."); return; }
  state.businessName = value;
  saveState();
  applyBusinessName();
  showToast("تم حفظ الاسم.");
}

function renderGuide() {
  if (els.businessNameInput && document.activeElement !== els.businessNameInput) {
    els.businessNameInput.value = businessName();
  }
  if (!els.guideLive) return;
  const cash = cashOnHand().total.current;
  const last = localStorage.getItem(LAST_BACKUP_KEY);
  const days = last ? Math.floor((Date.now() - new Date(last).getTime()) / 86400000) : null;
  const backupText = last ? `آخر نسخة احتياطية قبل ${days} يوم` : "ما في نسخة احتياطية بعد ⚠️";
  const backupClass = (!last || days >= 7) ? "guide-live-warn" : "guide-live-ok";
  const lastClose = (state.periodCloses || []).slice().sort((a, b) => String(b.to).localeCompare(String(a.to)))[0];
  const health = dataHealthReport();
  const healthClass = health.ok ? "guide-live-ok" : "guide-live-warn";
  const healthText = health.ok ? "سليم" : health.issues.slice(0, 2).join("، ");
  if (els.guideBackupStatus) {
    els.guideBackupStatus.textContent = last
      ? `آخر نسخة قبل ${days} يوم — ${days >= 7 ? "متأخرة، صدّر نسخة الآن" : "تمام"}`
      : "ما في نسخة بعد — صدّر نسخة واحفظها بمكان آمن";
  }
  els.guideLive.innerHTML = `
    <article class="guide-live-card"><span>💵 الكاش اللي معك الآن</span><strong>${money(cash)}</strong></article>
    <article class="guide-live-card ${backupClass}"><span>🛡️ النسخ الاحتياطي</span><strong>${backupText}</strong></article>
    <article class="guide-live-card"><span>🔒 آخر إغلاق</span><strong>${lastClose ? lastClose.to : "لا يوجد"}</strong></article>
    <article class="guide-live-card ${healthClass}"><span>🧪 صحة البيانات</span><strong>${escapeHtml(healthText || "راجع البيانات")}</strong></article>
    <article class="guide-live-card"><span>🧾 سجل التدقيق</span><strong>${(state.auditLog || []).length} عملية</strong></article>
  `;

  const auditHost = document.getElementById("auditLogList");
  if (auditHost) {
    const rows = (state.auditLog || []).slice(0, 8);
    auditHost.innerHTML = rows.length
      ? `<div class="audit-log-head"><strong>آخر عمليات التدقيق</strong><span>آخر ${rows.length} من ${state.auditLog.length}</span></div>
        ${rows.map((entry) => `
          <article class="audit-log-row">
            <span>${escapeHtml(auditActionLabel(entry.action))}</span>
            <small>${formatDate(entry.createdAt)}</small>
          </article>
        `).join("")}`
      : "";
  }
}

function auditActionLabel(action) {
  return {
    "backup.import": "استيراد نسخة احتياطية",
    "customers.import": "استيراد عملاء",
    "invoices.import": "استيراد فواتير",
    "menu.import": "استيراد أصناف",
    "invoice.edit": "تعديل فاتورة",
    "invoice.delete": "حذف فاتورة",
    "purchase.create": "إضافة فاتورة مشتريات",
    "purchase.edit": "تعديل فاتورة مشتريات",
    "purchase.delete": "حذف فاتورة مشتريات",
    "expense.create": "إضافة مصروف",
    "expense.delete": "حذف مصروف",
    "owner_withdrawal.create": "تسجيل سحب حصة",
    "owner_withdrawal.delete": "حذف سحب حصة",
    "period_close.approve": "اعتماد إغلاق فترة",
    "period_close.delete": "حذف إغلاق فترة",
    "workers.pay_all": "تسوية رواتب العمال"
  }[action] || action || "عملية";
}

// ─── تقرير نهاية اليوم (Z-Report) ───────────────────────────────────────────

function printDayReport() {
  const todayKey = todayDateInputValue();
  const range = { minDate: todayKey, maxDate: todayKey };
  const data = reportData(range);

  const paymentsReceived = data.paymentInvoices.reduce((sum, invoice) => sum + Number(invoice.paid || 0), 0);
  const averageInvoice = data.saleInvoices.length ? data.salesTotal / data.saleInvoices.length : 0;
  const collectionRate = data.salesTotal > 0 ? (data.paidTotal / data.salesTotal) * 100 : 0;
  const itemProfitMargin = data.salesTotal > 0 ? (data.itemProfit / data.salesTotal) * 100 : 0;
  const methodRows = paymentMethods.map((method) => `
    <tr>
      <td>${paymentLabels[method]}</td>
      <td>${money(data.invoicePayments[method] || 0)}</td>
    </tr>
  `).join("");

  const host = document.createElement("div");
  host.className = "print-host";
  host.innerHTML = `
    <div class="print-invoice">
      <h1>🧾 تقرير نهاية اليوم — ${escapeHtml(businessName())}</h1>
      <p class="print-meta">${formatDate(new Date().toISOString())}</p>
      <table class="statement-table">
        <tr><th>عدد فواتير البيع</th><td>${quantityText(data.saleInvoices.length)}</td></tr>
        <tr><th>إجمالي المبيعات</th><td>${money(data.salesTotal)}</td></tr>
        <tr><th>المقبوض من البيع</th><td>${money(data.paidTotal)}</td></tr>
        <tr><th>متوسط الفاتورة</th><td>${data.saleInvoices.length ? money(averageInvoice) : "لا يوجد"}</td></tr>
        <tr><th>نسبة التحصيل</th><td>${data.salesTotal > 0 ? `${collectionRate.toFixed(1)}%` : "لا يوجد"}</td></tr>
        <tr><th>هامش ربح الأصناف</th><td>${data.salesTotal > 0 ? `${itemProfitMargin.toFixed(1)}%` : "لا يوجد"}</td></tr>
        <tr><th>ديون جديدة اليوم</th><td>${data.debtTotal > 0.001 ? money(data.debtTotal) : "لا يوجد"}</td></tr>
        <tr><th>الدين الحالي للعملاء</th><td>${data.customerSummary.debt > 0.001 ? money(data.customerSummary.debt) : "لا يوجد"}</td></tr>
        <tr><th>سداد ديون (دفعات عملاء)</th><td>${money(paymentsReceived)}</td></tr>
        <tr><th>المشتريات</th><td>${money(data.purchasesTotal)}</td></tr>
        <tr><th>ربح الأصناف</th><td>${money(data.itemProfit)}</td></tr>
      </table>
      <h1 style="font-size:14px;margin-top:14px;">حسب طريقة الدفع (بيع وتسديد)</h1>
      <table class="statement-table">${methodRows}</table>
      <p class="print-meta" style="margin-top:14px;">قارن المجموع مع الصندوق قبل الإغلاق ✍</p>
    </div>
  `;
  document.body.appendChild(host);
  window.print();
  host.remove();
}

// ─── تنبيه نقص المخزون ──────────────────────────────────────────────────────

function lowStockItems() {
  const threshold = Number(state.lowStockThreshold || 0);
  const purchaseItems = purchaseInventoryItems();
  const menuItems = state.menu.filter((item) => isStockTracked(item) && !menuItemComponents(item).length);
  return purchaseItems.concat(menuItems)
    .filter((item) => Number(item.stockQty || 0) <= threshold)
    .sort((a, b) => Number(a.stockQty || 0) - Number(b.stockQty || 0));
}

function renderLowStock() {
  if (!els.lowStockPanel) return;
  els.lowStockThresholdInput.value = state.lowStockThreshold;
  const items = lowStockItems();

  els.lowStockList.innerHTML = items.length
    ? items.map((item) => `
      <article class="low-stock-row ${Number(item.stockQty || 0) <= 0 ? "is-empty" : ""}">
        <strong>${escapeHtml(item.name)}</strong>
        <span>${quantityWithUnit(Number(item.stockQty || 0), itemUnit(item))}</span>
      </article>
    `).join("")
    : '<div class="empty-state">كل المخزون فوق حد التنبيه ✓</div>';

  // شارة على تبويب الجرد
  const inventoryTab = Array.from(els.tabs).find((tab) => tab.dataset.view === "inventory");
  if (inventoryTab) {
    let badge = inventoryTab.querySelector(".tab-alert-badge");
    if (items.length) {
      if (!badge) {
        badge = document.createElement("span");
        badge.className = "tab-alert-badge";
        inventoryTab.appendChild(badge);
      }
      badge.textContent = items.length;
    } else if (badge) {
      badge.remove();
    }
  }
}

// ─── الأكثر مبيعاً + أوقات الذروة ───────────────────────────────────────────

function renderTopItemsAndPeakHours() {
  if (!els.reportTopItemsList) return;
  const range = selectedReportRange();
  const saleInvoices = state.invoices.filter((invoice) => invoice.type === "sale" && dateMatchesRange(invoice, range));

  // الأكثر مبيعاً
  const totals = new Map();
  saleInvoices.forEach((invoice) => {
    (invoice.items || []).forEach((line) => {
      const key = line.name;
      const entry = totals.get(key) || { name: line.name, qty: 0, sales: 0 };
      entry.qty += Number(line.qty || 0);
      entry.sales += Number(line.qty || 0) * Number(line.price || 0);
      totals.set(key, entry);
    });
  });
  const top = Array.from(totals.values()).sort((a, b) => b.qty - a.qty).slice(0, 10);
  const maxQty = top.length ? top[0].qty : 0;

  els.reportTopItemsList.innerHTML = top.length
    ? top.map((entry, index) => `
      <article class="top-item-row">
        <span class="top-item-rank">${index + 1}</span>
        <div class="top-item-info">
          <strong>${escapeHtml(entry.name)}</strong>
          <div class="top-item-bar"><div class="top-item-bar-fill" style="width:${maxQty ? Math.round((entry.qty / maxQty) * 100) : 0}%"></div></div>
        </div>
        <span class="top-item-figures">${quantityText(entry.qty)} | ${money(entry.sales)}</span>
      </article>
    `).join("")
    : '<div class="empty-state">لا توجد مبيعات ضمن الفترة.</div>';

  // أوقات الذروة
  const hours = new Array(24).fill(0);
  saleInvoices.forEach((invoice) => {
    const hour = new Date(invoice.createdAt).getHours();
    hours[hour] += Number(invoice.total || 0);
  });
  const maxHour = Math.max(...hours);

  els.reportHoursChart.innerHTML = maxHour > 0
    ? `<div class="peak-hours-bars">${hours.map((value, hour) => `
        <div class="peak-hour-col ${value === maxHour ? "is-peak" : ""}" title="الساعة ${hour}:00 — ${money(value)}">
          <div class="peak-hour-bar" style="height:${Math.max(Math.round((value / maxHour) * 100), value > 0 ? 4 : 0)}%"></div>
          <span class="peak-hour-label">${hour}</span>
        </div>
      `).join("")}</div>
      <p class="peak-hours-note">أعلى ذروة: الساعة ${hours.indexOf(maxHour)}:00 بمبيعات ${money(maxHour)}</p>`
    : '<div class="empty-state">لا توجد مبيعات ضمن الفترة.</div>';

  // مبيعات آخر 14 يوم (مستقل عن فلتر الفترة)
  const dailyHost = document.getElementById("reportDailyChart");
  if (dailyHost) {
    const dayKeyFor = (date) => {
      const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
      return local.toISOString().slice(0, 10);
    };
    const days = [];
    const dayIndex = {};
    const base = new Date();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(base);
      d.setDate(base.getDate() - i);
      const key = dayKeyFor(d);
      dayIndex[key] = days.length;
      days.push({ key, label: `${d.getDate()}/${d.getMonth() + 1}`, total: 0 });
    }
    state.invoices.forEach((invoice) => {
      if (invoice.type !== "sale") return;
      const k = (invoice.createdAt || "").slice(0, 10);
      if (k in dayIndex) days[dayIndex[k]].total += Number(invoice.total || 0);
    });
    const maxDay = Math.max(...days.map((d) => d.total), 0);
    const totalRange = days.reduce((sum, d) => sum + d.total, 0);
    dailyHost.innerHTML = maxDay > 0
      ? `<div class="daily-bars">${days.map((d) => `
          <div class="daily-col ${d.total === maxDay ? "is-peak" : ""}" title="${d.label} — ${money(d.total)}">
            <div class="daily-bar" style="height:${Math.max(Math.round((d.total / maxDay) * 100), d.total > 0 ? 4 : 0)}%"></div>
            <span class="daily-label">${d.label}</span>
          </div>`).join("")}</div>
        <p class="peak-hours-note">إجمالي آخر 14 يوم: ${money(totalRange)} — أعلى يوم: ${money(maxDay)}</p>`
      : '<div class="empty-state">لا توجد مبيعات في آخر 14 يوم.</div>';
  }
}

// ═══ قفل البرنامج برمز PIN ══════════════════════════════════════
// تخزين الرمز مُجزّأ (hash) حتى لا يظهر صريحًا في النسخة الاحتياطية.
function hashPin(raw) {
  const text = String(raw || "");
  let h = 5381;
  for (let i = 0; i < text.length; i++) {
    h = ((h << 5) + h + text.charCodeAt(i)) >>> 0;
  }
  return "p" + h.toString(36);
}

function hasAppPin() {
  return !!(state.appPin && String(state.appPin).length);
}

function isValidPinFormat(raw) {
  return /^\d{4,6}$/.test(String(raw || ""));
}

function setAppPin(raw) {
  if (!isValidPinFormat(raw)) {
    showToast("الرمز لازم يكون 4 إلى 6 أرقام.");
    return false;
  }
  state.appPin = hashPin(raw);
  saveState();
  showToast("تم تفعيل قفل البرنامج. 🔒");
  renderPinSettings();
  return true;
}

function clearAppPin(currentRaw) {
  if (!hasAppPin()) return true;
  if (hashPin(currentRaw) !== state.appPin) {
    showToast("الرمز الحالي غير صحيح.");
    return false;
  }
  state.appPin = "";
  saveState();
  showToast("تم إلغاء قفل البرنامج.");
  renderPinSettings();
  return true;
}

// شاشة القفل عند فتح البرنامج
function showLockScreen() {
  if (!hasAppPin()) return;
  if (document.getElementById("appLockOverlay")) return;
  const overlay = document.createElement("div");
  overlay.id = "appLockOverlay";
  overlay.className = "app-lock-overlay";
  overlay.innerHTML = `
    <div class="app-lock-box">
      <div class="app-lock-icon">🔒</div>
      <h2>${escapeHtml(state.businessName || "دفتر المقهى")}</h2>
      <p>اكتب رمز الدخول</p>
      <input id="appLockInput" class="app-lock-input" type="password" inputmode="numeric" autocomplete="off" maxlength="6" />
      <div class="app-lock-error" id="appLockError" hidden>الرمز غير صحيح</div>
      <button class="primary-button wide" id="appLockSubmitButton" type="button">دخول</button>
    </div>
  `;
  document.body.appendChild(overlay);
  document.body.classList.add("is-locked");
  const input = document.getElementById("appLockInput");
  const submit = document.getElementById("appLockSubmitButton");
  const tryUnlock = () => {
    if (hashPin(input.value) === state.appPin) {
      overlay.remove();
      document.body.classList.remove("is-locked");
    } else {
      const err = document.getElementById("appLockError");
      if (err) err.hidden = false;
      const box = overlay.querySelector(".app-lock-box");
      if (box) {
        box.classList.remove("is-shake");
        void box.offsetWidth;
        box.classList.add("is-shake");
      }
      input.value = "";
      input.focus();
    }
  };
  submit.addEventListener("click", tryUnlock);
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") tryUnlock(); });
  setTimeout(() => input.focus(), 50);
}

// صندوق إعداد القفل في صفحة الدليل
function renderPinSettings() {
  const statusEl = document.getElementById("pinStatusText");
  const setBox = document.getElementById("pinSetBox");
  const clearBox = document.getElementById("pinClearBox");
  if (!statusEl || !setBox || !clearBox) return;
  if (hasAppPin()) {
    statusEl.textContent = "القفل مُفعّل — البرنامج بيطلب الرمز عند الفتح.";
    setBox.hidden = true;
    clearBox.hidden = false;
  } else {
    statusEl.textContent = "القفل غير مفعّل — أي حدا بيفتح الجهاز بيشوف كل البيانات.";
    setBox.hidden = false;
    clearBox.hidden = true;
  }
}

// ═══ حجم الطباعة (A4 / إيصال حراري 80mm / 58mm) ═════════════════
function applyPrintSize() {
  const mode = ["a4", "80mm", "58mm"].includes(state.printSize) ? state.printSize : "a4";
  let styleEl = document.getElementById("printPageSizeStyle");
  if (!styleEl) {
    styleEl = document.createElement("style");
    styleEl.id = "printPageSizeStyle";
    document.head.appendChild(styleEl);
  }
  if (mode === "a4") { styleEl.textContent = ""; return; }
  const pageW = mode === "58mm" ? "58mm" : "80mm";
  const invW = mode === "58mm" ? "52mm" : "74mm";
  const fs = mode === "58mm" ? "11px" : "12px";
  const h1 = mode === "58mm" ? "14px" : "16px";
  const margin = mode === "58mm" ? "2mm" : "3mm";
  styleEl.textContent = `@media print {
    @page { size: ${pageW} auto; margin: ${margin}; }
    .print-host { padding: 0 !important; }
    .print-invoice { width: ${invW} !important; margin: 0 auto !important; font-size: ${fs} !important; }
    .print-invoice h1 { font-size: ${h1} !important; text-align: center !important; margin-bottom: 4px !important; }
    .print-meta { text-align: center !important; font-size: 10.5px !important; margin-bottom: 8px !important; }
    .print-lines p, .print-total p { font-size: ${fs} !important; }
    .statement-table, .statement-summary { font-size: 9px !important; }
  }`;
}

function renderPrintSizeSetting() {
  const sel = document.getElementById("printSizeSelect");
  if (sel) sel.value = state.printSize || "a4";
}
